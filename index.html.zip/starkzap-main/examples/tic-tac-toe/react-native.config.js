export default {
  dependencies: {},
};
