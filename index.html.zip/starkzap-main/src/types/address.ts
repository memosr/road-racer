import { type BigNumberish, validateAndParseAddress } from "starknet";

/**
 * Branded type for Starknet addresses.
 *
 * This provides compile-time type safety to distinguish addresses from
 * regular strings, while remaining a string at runtime.
 */
export type Address = string & { readonly __type: "StarknetAddress" };
export type AddressInput = BigNumberish | { address: BigNumberish };

/**
 * Parse a Starknet address from a BigNumberish value.
 * @param value - The address to parse
 * @returns The validated address
 * @throws Argument must be a valid address inside the address range bound
 */
export function fromAddress(value: BigNumberish): Address {
  return validateAndParseAddress(value) as Address;
}

/**
 * Resolve an address input to a validated Address.
 *
 * Accepts either a raw address-like value or an object containing an `address` field
 * (e.g. WalletInterface-compatible objects).
 */
export function resolveWalletAddress(value: AddressInput): Address {
  if (value && typeof value === "object" && "address" in value) {
    return fromAddress((value as { address: BigNumberish }).address);
  }

  return fromAddress(value);
}

/**
 * Branded type for Ethereum addresses.
 *
 * This provides compile-time type safety to distinguish addresses from
 * regular strings, while remaining a string at runtime.
 */
export type EthereumAddress = string & { readonly __type: "EthereumAddress" };

/**
 * Branded type for Solana addresses.
 *
 * This provides compile-time type safety to distinguish addresses from
 * regular strings, while remaining a string at runtime.
 */
export type SolanaAddress = string & { readonly __type: "SolanaAddress" };

export type ExternalAddress = EthereumAddress | SolanaAddress;
